package com.svn.emptrydir.restore;

import java.io.File;
import java.io.IOException;

public class SvnEmptyDirRestore {
	public static final String packageFile = ".keep_svn_empty_dir";  
	  
    public static void main(String[] args) {  
        String path = getRealPath();  
        File file = new File(path);  
        try {  
            traversalAllFolder(file);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
  
    /** 
     * ������ǰ�ļ����µ������ļ��У�ɾ��.keep_svn_empty_dir�ļ� 
     *  
     * @param dir 
     * @throws Exception 
     */  
    final static void traversalAllFolder(File dir) throws Exception {  
    	deleteFile(dir.getAbsolutePath());  
        File[] fs = dir.listFiles();  
        int fsLength = fs.length;   
        for (int i = 0; i < fsLength; i++) {  
            if (fs[i].isDirectory()) {  
                try {  
                    traversalAllFolder(fs[i]); 
                } catch (Exception e){
                	
                }  
            }  
        }  
    }  
  
    /** 
     * ɾ��.keep_svn_empty_dir�ļ� 
     *  
     * @param folderPath 
     *            ·���� 
     */  
    public static void deleteFile(String folderPath) {  
        String fileName = folderPath + "/" + packageFile;  
        File file = new File(fileName);  
        try {  
        	if(file.isFile() && file.exists()){
        		file.delete();
        	}
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
  
    /** 
     * ��ȡ��ǰjar������·�� 
     *  
     * @return 
     */  
    public static String getRealPath() {  
        String realPath = SvnEmptyDirRestore.class.getClassLoader().getResource("")  
                .getFile();  
        java.io.File file = new java.io.File(realPath);  
        realPath = file.getAbsolutePath();  
        try {  
            realPath = java.net.URLDecoder.decode(realPath, "utf-8");  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
  
        return realPath;  
    }  
}
