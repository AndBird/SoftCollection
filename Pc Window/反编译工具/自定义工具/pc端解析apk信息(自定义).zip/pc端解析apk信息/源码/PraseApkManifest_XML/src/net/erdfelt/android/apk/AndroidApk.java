package net.erdfelt.android.apk;

import net.erdfelt.android.apk.io.IO;
import net.erdfelt.android.apk.xml.Attribute;
import net.erdfelt.android.apk.xml.BinaryXmlListener;
import net.erdfelt.android.apk.xml.BinaryXmlParser;

import java.awt.Label;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

public class AndroidApk {
    public String appName;
    public String appVersionName;
    public String appVersionCode;
    public String packageName;
    public String minSdkVersion;
    public String targetSdkVersion;
    public String maxSdkVersion;
    
    
    public List<String> permissions = new ArrayList<String>();
    public List<String> activityList = new ArrayList<String>();
    public List<String> mainActivityList = new ArrayList<String>();
    public List<String> serviceList = new ArrayList<String>();
    public List<String> receiverList = new ArrayList<String>();
    public List<String> providerList = new ArrayList<String>();
    public List<String> metaDataList = new ArrayList<String>();
    public List<String> otherInfoList = new ArrayList<String>();
    
    private String tmpMainActivity = "";

    private class ManifestListener implements BinaryXmlListener {
        public void onXmlEntry(String path, String name, Attribute... attrs) {
            if ("//".equals(path) && "manifest".equals(name)) {
                for (Attribute attrib : attrs) {
                    if ("package".equals(attrib.getName())) {
                        packageName = attrib.getValue();
                    } else if ("versionName".equals(attrib.getName())) {
                        appVersionName = attrib.getValue();
                    } else if ("versionCode".equals(attrib.getName())) {
                        appVersionCode = attrib.getValue();
                    }
                }
            }

            if ("uses-sdk".equals(name)) {
                for (Attribute attrib : attrs) {
                    if ("minSdkVersion".equals(attrib.getName())) {
                        minSdkVersion = attrib.getValue();
                    } else if ("targetSdkVersion".equals(attrib.getName())) {
                        targetSdkVersion = attrib.getValue();
                    } else if ("maxSdkVersion".equals(attrib.getName())) {
                        maxSdkVersion = attrib.getValue();
                    }
                }
            }
            
            if("uses-permission".equals(name)){//����Ȩ��
                for (Attribute attrib : attrs) {
                    permissions.add(attrib.getValue());
                }
            }
            
        
            if("activity".equals(name)){//����activity
                for (Attribute attrib : attrs) {
                    //System.out.println(attrib.getName());
                    if("name".equals(attrib.getName())){
                        //ֻȡactivity������
                        activityList.add(attrib.getValue());
                        tmpMainActivity = attrib.getValue();
                        //System.out.println(attrib.getValue());
                    }
                }
            }
            
           //���activity
           //if("intent-filter".equals(name)){ 
               for (Attribute attrib : attrs) {
                     if("name".equals(attrib.getName()) && "android.intent.action.MAIN".equals(attrib.getValue()) 
                            || "name".equals(attrib.getName()) && "android.intent.category.LAUNCHER".equals(attrib.getValue())){
                         if(tmpMainActivity != null && !tmpMainActivity.equals("")){
                             mainActivityList.add(tmpMainActivity);
                             System.out.println("main:" + tmpMainActivity);
                             tmpMainActivity = null;
                         }
                     }
               }
          //}
            
            if("service".equals(name)){//����service
                for (Attribute attrib : attrs) {
                    //System.out.println(attrib.getName());
                    if("name".equals(attrib.getName())){
                        //ֻȡservice������
                       serviceList.add(attrib.getValue());
                    }
                }
            }
            
            
            
            if("receiver".equals(name)){//����receiver
                for (Attribute attrib : attrs) {
                    //System.out.println(attrib.getName());
                    if("name".equals(attrib.getName())){
                        //ֻȡreceiver������
                        receiverList.add(attrib.getValue());
                    }
                }
            }
            
            if("provider".equals(name)){//����provider
                for (Attribute attrib : attrs) {
                    //System.out.println(attrib.getName());
                    if("name".equals(attrib.getName())){
                        //ֻȡprovider������
                        providerList.add(attrib.getValue());
                    }
                }
            }
            
            if("meta-data".equals(name)){//����meta-data
                int i = 0;
                String tmp = "";
                for (Attribute attrib : attrs) {
                    i++;
                    if(i % 2 == 0){
                        metaDataList.add(name + " " + tmp + "=" + attrib.getValue());
                    }else{
                        tmp = attrib.getValue();
                    }
                    //System.out.println(attrib.getName());
                }
            }
            
            if("application".equals(name)){//label ��iconid
                int i = 0;
                String tmp = "";
                for (Attribute attrib : attrs) {
                    if("label".equals(attrib.getName())){
                        //label 
                        System.out.println("label id=" + attrib.getValue());
                    }
                    
                    if("icon".equals(attrib.getName())){
                        //icon
                        System.out.println("icon id=" + attrib.getValue());
                    }
                }
            }
            
//            //������
//            String string = name + ":   ";
//            for (Attribute attrib : attrs) {
//               string = string + attrib.getName() + "=" + attrib.getValue() + "  ";
//            }
//            otherInfoList.add(string);
//            System.out.println(string);
        }
    }

    public AndroidApk(File apkfile) throws ZipException, IOException {
        ZipFile zip = null;
        InputStream in = null;
        try {
            zip = new ZipFile(apkfile);
            //����AndroidManifest.xml
            ZipEntry manifestEntry = zip.getEntry("AndroidManifest.xml");
            if (manifestEntry == null) {
                throw new FileNotFoundException("Cannot find AndroidManifest.xml in apk");
            }

            in = zip.getInputStream(manifestEntry);
            parseStream(in);
            
            //����ͼ���Ӧ����
          /*  BinaryXmlParser parser = new BinaryXmlParser();
             //parser.addListener(new BinaryXmlDump());
            parser.addListener(new ManifestListener()); //���ûص�
            parser.parse(in);*/
            
        } finally {
            IO.close(in);
            try {
                if (zip != null) {
                    zip.close();
                }
            } catch (IOException ignore) {
                /* ignore */
            }
        }
    }

    /**
     * Takes as an input APK as a stream. At the end, the stream is closed.
     * 
     * @param apkfileInputStream
     *            apk file stream
     * @throws IOException
     *             in case of error of reading/parsing data
     */
    public AndroidApk(InputStream apkfileInputStream) throws IOException {
        InputStream in = null;
        try {
            final ZipInputStream is = new ZipInputStream(apkfileInputStream);
            ZipEntry ze;
            while (((ze = is.getNextEntry()) != null) && !ze.getName().endsWith("AndroidManifest.xml")) {
                // continue 
            }
            in = is;
            if (ze == null) {
                throw new FileNotFoundException("Cannot find AndroidManifest.xml in apk");
            }

            parseStream(in);
        } finally {
            IO.close(in);
        }
    }

    private void parseStream(InputStream in) throws IOException {
        BinaryXmlParser parser = new BinaryXmlParser();
        // parser.addListener(new BinaryXmlDump());
        parser.addListener(new ManifestListener()); //���ûص�
        parser.parse(in);
    }

    public String getAppVersion() {
        return appVersionName;
    }

    public String getAppVersionCode() {
        return appVersionCode;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getMinSdkVersion() {
        return minSdkVersion;
    }

    public String getTargetSdkVersion() {
        return targetSdkVersion;
    }

    public String getMaxSdkVersion() {
        return maxSdkVersion;
    }

    public List<String> getPermissions() {
        return permissions;
    }
    
    

}
