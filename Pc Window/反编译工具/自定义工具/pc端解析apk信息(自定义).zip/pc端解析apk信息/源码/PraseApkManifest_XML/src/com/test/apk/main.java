package com.test.apk;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import net.erdfelt.android.apk.AndroidApk;

public class main {
   
    /**
     * @param args
     */
    public static void main(String[] args) {
       String dirPath = System.getProperty("user.dir");
       String filePath = dirPath + File.separator + "1.apk";
        try {
            System.out.println("ִ��");
            File apkfile = new File(filePath);
            if(!apkfile.exists()){
                System.out.println("�ļ�������");
                return ;
            }
            AndroidApk apk = new AndroidApk(apkfile);
            
            System.out.println(System.getProperty("user.dir"));
            System.out.println(apk.appVersionName);
            System.out.println(apk.appVersionCode);
            System.out.println(apk.packageName);
            System.out.println(apk.minSdkVersion);
            System.out.println(apk.targetSdkVersion);
            System.out.println(apk.maxSdkVersion);  
            
            saveToFile(apk);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    
    private static void saveToFile(AndroidApk apk){
        FileWriter writer = null;
        BufferedWriter bw = null;
        try {
            //����Ŀ¼
            String dirPath =System.getProperty("user.dir");
            File dir = new File(dirPath + File.separator + apk.packageName);
            dir.mkdirs();
            //�����ļ�
            File file =  new File(dir, apk.packageName + ".txt");
            
            writer = new FileWriter(file); 
            bw = new BufferedWriter(writer);
            bw.write("packageName:" + apk.packageName);
            bw.newLine();
            bw.write("appVersionName:" + apk.appVersionName);
            bw.newLine();
            bw.write("appVersionCode:" + apk.appVersionCode);
            bw.newLine();
            bw.write("maxSdkVersion:" + apk.maxSdkVersion);
            bw.newLine();
            bw.write("minSdkVersion:" + apk.minSdkVersion);
            bw.newLine();
            bw.write("targetSdkVersion:" + apk.targetSdkVersion);
            bw.newLine();
            
            //��ӡȨ��
            bw.newLine();
            bw.newLine();
            bw.write("all permissions:");
            bw.newLine();
            for(int i = 0; i < apk.permissions.size(); i++){
                bw.write(apk.permissions.get(i));
                bw.newLine();
            }
            
            //��ӡactivity
            if(apk.mainActivityList != null && apk.mainActivityList.size() > 0){
                bw.newLine();
                bw.newLine();
                bw.write("main activity:");
                bw.newLine();
                for(int i = 0; i < apk.mainActivityList.size(); i++){
                    bw.write(apk.mainActivityList.get(i));
                    bw.newLine();
                }
            }
            
            
            bw.newLine();
            bw.newLine();
            bw.write("all activity:");
            bw.newLine();
            for(int i = 0; i < apk.activityList.size(); i++){
                bw.write(apk.activityList.get(i));
                bw.newLine();
            }
            
            //��ӡservice
            bw.newLine();
            bw.newLine();
            bw.write("all service:");
            bw.newLine();
            for(int i = 0; i < apk.serviceList.size(); i++){
                bw.write(apk.serviceList.get(i));
                bw.newLine();
            }
            
            
            //��ӡreceiver
            bw.newLine();
            bw.newLine();
            bw.write("all receiver:");
            bw.newLine();
            for(int i = 0; i < apk.receiverList.size(); i++){
                bw.write(apk.receiverList.get(i));
                bw.newLine();
            }
            
            //��ӡprovider
            bw.newLine();
            bw.newLine();
            bw.write("all provider:");
            bw.newLine();
            for(int i = 0; i < apk.providerList.size(); i++){
                bw.write(apk.providerList.get(i));
                bw.newLine();
            }
            
            //meta-data
            bw.newLine();
            bw.newLine();
            bw.write("meta-data:");
            bw.newLine();
            for(int i = 0; i < apk.metaDataList.size(); i++){
                bw.write( apk.metaDataList.get(i));
                bw.newLine();
            }
            
            //������Ϣ
            bw.newLine();
            bw.newLine();
            bw.write("Other:");
            bw.newLine();
            for(int i = 0; i < apk.otherInfoList.size(); i++){
                bw.write( apk.otherInfoList.get(i));
                bw.newLine();
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            try {
                bw.close();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
